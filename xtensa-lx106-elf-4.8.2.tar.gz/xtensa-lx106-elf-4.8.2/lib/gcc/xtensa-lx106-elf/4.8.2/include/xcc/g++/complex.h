/*  Customer ID=7011; Build=0x2b6f6; Copyright (C) 2007--2009 Tensilica, Inc. */
// -*- C++ -*- backward compatiblity header.
// Copyright (C) 1994 Free Software Foundation

#ifndef __COMPLEX_H__
#include <complex>
#endif
