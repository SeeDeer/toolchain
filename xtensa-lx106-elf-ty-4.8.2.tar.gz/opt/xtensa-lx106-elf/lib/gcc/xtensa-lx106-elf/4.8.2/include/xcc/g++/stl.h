/*  Customer ID=7011; Build=0x2b6f6; Copyright (C) 2007--2009 Tensilica, Inc. */
// -*- C++ -*- compatibility header.
// This file is part of the GNU ANSI C++ Library.

#include <algorithm>
#include <deque>
#include <functional>
#include <iterator>
#include <list>
#include <map>
#include <memory>
#include <numeric>
#include <set>
#include <stack>
#include <utility>
#include <vector>
